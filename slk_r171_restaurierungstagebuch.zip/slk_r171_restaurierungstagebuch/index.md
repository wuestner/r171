---
layout: home
title: "SLK R171 Restaurierungstagebuch"
subtitle: "Willkommen im Restaurierungstagebuch meines Mercedes SLK R171 Kompressor."
---

## Übersicht

Hier dokumentiere ich Wartungen, Pflege und Upgrades rund um meinen Mercedes SLK R171.

## Letzte Einträge

{% for post in site.posts limit:5 %}
- [{{ post.title }}]({{ post.url }}) – {{ post.date | date: "%d.%m.%Y" }}
{% endfor %}

---

## Wartungshistorie

Hier erscheinen alle Wartungseinträge chronologisch.

{% for post in site.posts %}
### [{{ post.title }}]({{ post.url }})
> {{ post.excerpt }}

{% endfor %}
